let modal = document.querySelector('.modal');

modal.classList.add('hide');

document.onkeydown = function(e){
	if(e.key == 'Enter'){
		modal.classList.remove('hide');
	} else if(e.keyCode == 27){
		modal.classList.add('hide');
		return false;
	}
}

document.querySelector('.close__btn').onclick = function(){
  	modal.classList.add('hide');
}

