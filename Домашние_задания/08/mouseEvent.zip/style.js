
//////// TASK 1 ////////
let elem = document.querySelector(".click");
elem.ondblclick = _ => {
    alert("event");
}
document.oncontextmenu = function (ev) {
    ev.preventDefault();
}

//////// TASK 2 ////////
let elemFolder = document.querySelector(".folder");

elemFolder.onmouseenter = openFolder;
elemFolder.onmouseleave = closeFolder;

function openFolder() {
    this.style.background = "url(open.png)"
}
function closeFolder() {
    this.style.background = "url(close.png)"
}

//////// TASK 3 ////////

function randColor(min = 0, max = 255) {
    let r, g, b;
    r = Math.floor(Math.random() * (max - min + 1)) + min;
    g = Math.floor(Math.random() * (max - min + 1)) + min;
    b = Math.floor(Math.random() * (max - min + 1)) + min;
    return `rgb(${r},${g},${b})`;
}

function changeColor() {
    this.style.background = randColor();
}

let itemColor1 = document.querySelector(".first-item");
let itemColor2 = document.querySelector(".second-item");
let itemColor3 = document.querySelector(".third-item");

itemColor1.onmouseenter = changeColor;
itemColor2.onmouseenter = changeColor;
itemColor3.onmouseenter = changeColor;

//////// TASK 3 variant 2////////
// let itemColor = document.querySelectorAll(".item");
// for(let i = 0; i < itemColor.length; i++){
//     itemColor[i].onmouseenter = changeColor;
// }