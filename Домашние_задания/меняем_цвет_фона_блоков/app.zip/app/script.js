// 1 событие

let block = document.querySelectorAll('.block');

// block.forEach(function (element) {
//     element.onmouseenter = changeBackground;
// });

// for (let i = 0; i < block.length; i++) {
//     block[i].onmouseenter = changeBackground;
// }

block.forEach(function (element) {
    element.addEventListener('mouseenter', changeBackground, true);
});

function changeBackground() {
    console.log('work');
    // style.background = rgb(200, 23, 170)
    //0..255
    this.style.background = 'rgb(' + ri() + ',' + ri() + ',' + ri() + ')';
    this.style.background = `rgb(${ri()},${ri()},${ri()})`;
}

function ri() {
    let min = 0;
    let max = 255;
    let rand = min + Math.random() * (max + 1 - min);
    rand = Math.floor(rand);
    return rand;
}